﻿namespace RivertyInterview.Models.Repository
{
	public enum RomanCalculationOperation
	{
		Add = 0,
		Subtract = 1,
	}
}
