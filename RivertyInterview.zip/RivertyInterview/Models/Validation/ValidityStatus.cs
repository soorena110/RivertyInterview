﻿namespace RivertyInterview.Models.Validation
{
    public enum ValidityStatus
    {
        Valid, Invalid, NotCheckedYet
    }
}
